import React from 'react'

const Step1 = () => {
    return (
        <div className='row'>
            <div className="col-2">
                Step 1 :
            </div >
            <div className='col'>
                Select File
                <form className='my-3'>
                    <input type="file" />
                </form>
                Supported File Type(s): CSV, JSON
            </div>
        </div>
    )
}

export default Step1
