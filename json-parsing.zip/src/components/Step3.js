import React from 'react';

const Step3 = () => {
  return (
    <div className="row">
      <div className="col-2">Step 3 :</div>
      <div className="col">
        Display Handling <br />
        Select the fields to be displayed <br />
      </div>
    </div>
  );
};

export default Step3;
