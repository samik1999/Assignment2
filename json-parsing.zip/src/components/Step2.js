import React from 'react';

const Step2 = () => {
  return (
    <div className="row">
      <div className="col-2">Step 2 :</div>
      <div className="col">
        Specify Format
        <form className="my-3">
          <div class="row mb-2">
            <div class="col-4">
              <label for="inputPassword6" class="col-form-label">
                File Type
              </label>
            </div>
            <div class="col">
              <select class="form-select" aria-label="Default select example">
                <option selected value="0">
                  csv
                </option>
                <option value="1">JSON</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </select>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-4">
              <label for="inputPassword6" class="col-form-label">
                Character Encoding
              </label>
            </div>
            <div class="col">
              <select class="form-select" aria-label="Default select example">
                <option selected value="0">
                  UTF-8
                </option>
                <option value="1">JSON</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </select>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-4">
              <label for="inputPassword6" class="col-form-label">
                Demiliter
              </label>
            </div>
            <div class="col">
              <select class="form-select" aria-label="Default select example">
                <option selected value="0">
                  comma
                </option>
                <option value="1">JSON</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </select>
            </div>
          </div>
          <div className="row ms-1">
            <div class="form-check">
              <input
                class="form-check-input"
                type="checkbox"
                value=""
                id="hasHeader"
              />
              <label class="form-check-label" for="flexCheckDefault">
                Has Header
              </label>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Step2;
