import './App.css';
import Step1 from './components/Step1';
import Step2 from './components/Step2';
import Step3 from './components/Step3';

function App() {
  return (
    <div className="container bg-light">
      Import Products
      <div className="step-row row">
        <div className="col-5 bg-white m-3 p-3">
          <Step1 />
        </div>
        <div className="col-6 bg-white m-3 p-3">
          <Step2 />
        </div>
      </div>
      <div className="step-row row">
        <div className="col-11 bg-white m-3 p-3">
          <Step3 />
        </div>
      </div>
    </div>
  );
}

export default App;
